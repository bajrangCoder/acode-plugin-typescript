# TypeScript Compiler
Live typescript compiler for Acode .

## Use
just make typescript file and write your , then save it will
automatically compile ts -> js in your typescript file directory.